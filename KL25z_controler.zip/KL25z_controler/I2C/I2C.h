#include "MKL25Z4.h"                    // Device header

//I2C function
void I2C_init();			/*I2C initialization function*/