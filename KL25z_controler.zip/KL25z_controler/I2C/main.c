#include "MKL25Z4.h"                    // Device header

void main(void){
	
};
